import { createContext } from "react";

const AlertContext = createContext();

export default AlertContext;
